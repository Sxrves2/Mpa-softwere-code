var studentNames = ["Aidan ", " Cody ", "Danil", "Kyle", "Jean", "David", "Harry", "Stefen", "Leah", "Ethen", "Tomas,", "Kaidyn", "Haiden", "Rowan", "Makstmillon", "Liam", "Jerry","Emanual",""];




studentNames.sort();
var i = 0;
for (i = 0; i < studentNames.length; i++) {

    document.write(" " + i + studentNames[i]);
}