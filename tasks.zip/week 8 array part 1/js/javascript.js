var myPlants = new Array();
    myPlants[0] = "mercury"; 
    myPlants[1] = "venus";
    myPlants[2] = "Earth";
    myPlants[3] = "mars";
    myPlants[4] = "jupiter";
    myPlants[5] = "saturn";
    myPlants[6] = "uranus";
    myPlants[7] = "neptune";

    

var distance = new Array();
    distance[0] = "46.345";
    distance[1] = "107.48";
    distance[2] = "148.54";
    distance[3] = "215.59";
    distance[4] = "766.01";
    distance[5] = "1.4927";
    distance[6] = "2.9589";
    distance[7] = "4.4762";

var i=0;
for (i=0; i<8; i++)
{
   document.write("the plant is " +myPlants[i] + "The distance between the plant and the sun is " +distance[i] +"()"); 
}