var i = 0;


var numbersCollection = new Array(); 
    
for (i = 0; i <6; i++)
{
    numbers = Math.floor(Math.random() * 25); 
    numbersCollection.push(numbers); 
    document.write(numbers +"</br>");
}



