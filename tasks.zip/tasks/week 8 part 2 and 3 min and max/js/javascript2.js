var numberList = [3,6,2,7,8,1];

for (var i = 0; i < numberList.length; i++)
{

    document.write(numberList[i] +"</br>"  );
    
}