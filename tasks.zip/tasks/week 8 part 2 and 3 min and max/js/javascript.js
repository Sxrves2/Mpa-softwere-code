var numberList = [5,6,12,45,98];

for (var i = 0; i < numberList.length; i++)
{

    document.write("Number " +(i+1)+ "in the array is " +numberList[i] +"</br>"  );
    
}