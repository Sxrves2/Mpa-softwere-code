var numberList = [3,6,2,7,8,1];
var max = 0;
var min = 0;


for (var i = 0; i < numberList.length; i++)
{
    if(numberList[i]> max)
    {
        max = numberList[i]
    }

    document.write(numberList[i] +"</br>"  );
    
}

alert(`the number of max is ${max}`);