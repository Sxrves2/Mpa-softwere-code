var numberList = [3,6,2,7,8,1];
var max = 0;
var min = 100;


for (var i = 0; i < numberList.length; i++)
{
    if(numberList[i]> max)
    {
        max = numberList[i]
    }

    if(numberList[i]< min)
    {
        min = numberList[i]
    }
    document.write(numberList[i] +"</br>"  );
    
}

alert("the number of max is value of max " +max + "and this is the value of min " +min);